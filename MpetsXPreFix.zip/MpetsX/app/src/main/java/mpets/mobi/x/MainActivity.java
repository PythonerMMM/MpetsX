package mpets.mobi.x;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.*;
import android.content.*;
import android.net.*;
import android.view.*;
import android.util.*;
import android.preference.*;
import java.io.*;
import android.content.res.*;
import java.net.*;

public class MainActivity extends Activity
{
	// Part 1
	private WebView mWebView;
	SharedPreferences sp;
	// Part 2
	String start = "javascript:(function() {";
	String end = "})()";
	// Part 3
	String first_inject = start+
	"document.body.innerHTML = document.body.innerHTML.replace('mad hatter.', 'Амад хатер');"+
	"document.getElementById('mobtop').style.display='none';"+
	"document.body.innerHTML = document.body.innerHTML.replace('BookOfShadow', 'Бог');"+
	end;
	String second_inject = start+
	"document.getElementsByTagName('link')[1].setAttribute('href', '')"+
	end;
	Context context;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		sp = PreferenceManager.getDefaultSharedPreferences(this);
		mWebView = (WebView) findViewById(R.id.mainWeb);
		// включаем поддержку JavaScript
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setSaveFormData(true);
		mWebView.getSettings().setSavePassword(true);
// указываем страницу загрузки
		mWebView.setWebViewClient(new MyWebViewClient());
		mWebView.loadUrl("http://mpets.mobi/welcome");
	}
	private class MyWebViewClient extends WebViewClient 
	{
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) 
		{
				view.loadUrl(url);
			return true;
		}
		@Override
		public void onPageFinished(WebView view, String url)
		{   
			iNCSG();
			Boolean economy = sp.getBoolean("economy", false);
			Boolean fast = sp.getBoolean("fast", false);
		if(economy == true) {
			mWebView.loadUrl(second_inject);
		} else {
			if(fast == true) {
				} else {
       mWebView.loadUrl(first_inject);
			}}
			if(url.equals("http://mpets.mobi/")) {
				Intent i = new Intent(getApplicationContext(), AuthActivity.class);
				finish();
				startActivity(i);
			}
			super.onPageFinished(view, url);
		}
	}
	@Override
	public void onBackPressed() {/*при нажатии на кнопку назад открываем предыдущее окно*/
		if(mWebView.canGoBack()) {
			mWebView.goBack();
		} else {
			super.onBackPressed();
		}
	}
	@Override
	protected void onResume()
	{
		iNCSG();
		Boolean economy = sp.getBoolean("economy", false);
		Boolean fast = sp.getBoolean("fast", false);
		if(economy==true){
			mWebView.getSettings().setLoadsImagesAutomatically(false);
		} else {
			mWebView.getSettings().setLoadsImagesAutomatically(true);
		}
		super.onResume();
	}
	public boolean isOnline() {
	ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    // test for connection
    if (cm.getActiveNetworkInfo() != null
	&& cm.getActiveNetworkInfo().isAvailable()
	&& cm.getActiveNetworkInfo().isConnected()) {
        return true;
    } else {
        Log.v("Tag", "Internet Connection Not Present");
        return false;
    }}
	public void iNCSG() {
		try {
        if(isOnline()) {
            // do logic
        } else {
            // show message network is not available.
			Intent i = new Intent(getApplicationContext(), GameActivity.class);
			startActivity(i);
        }} catch(Exception e) {
			Log.d("Tag", "" + e);
		}
	}
	}
