package mpets.mobi.x;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.*;
import android.content.*;
import android.net.*;
import android.view.*;
import android.util.*;
import android.preference.*;
import java.io.*;
import android.content.res.*;
import android.support.v4.widget.*;
import android.support.design.widget.*;
import java.util.*;
import android.view.View.*;
import org.jsoup.*;
import org.jsoup.nodes.*;
import org.jsoup.select.*;
import android.content.pm.*;
import android.content.pm.PackageManager.*;
import java.net.*;
import android.app.AlertDialog.*;
import android.graphics.*;

public class AuthActivity extends Activity
{
	int i = 0;
	Context context;
	private WebView mWebView;
	SharedPreferences sp;
	String start = "javascript:(function() {";
	String end = "})()";
	// Part 3
	String first_inject = start+
	"document.body.innerHTML = document.body.innerHTML.replace('mad hatter.', 'Амад хатер');"+
	"document.getElementById('mobtop').style.display='none';"+
	"document.body.innerHTML = document.body.innerHTML.replace('BookOfShadow', 'Бог');"+
	end;
	String second_inject = start+
	"document.getElementsByTagName('link')[1].setAttribute('href', '')"+
	end;
	private DrawerLayout mDrawerLayout;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
		navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(
			new NavigationView.OnNavigationItemSelectedListener() {
				@Override
				public boolean onNavigationItemSelected(MenuItem menuItem)
				{
					menuItem.setChecked(true);
					mDrawerLayout.closeDrawers();
					switch (menuItem.getItemId())
					{
						case R.id.home:
							mWebView.loadUrl("http://mpets.mobi");
							//mDrawerLayout.closeDrawers();
							return true;
						case R.id.mail:
							mWebView.loadUrl("http://mpets.mobi/view_posters");
							//mDrawerLayout.closeDrawers();
							return true;
						case R.id.chat:
							mWebView.loadUrl("http://mpets.mobi/chat");
							//mDrawerLayout.closeDrawers();
							return true;
						case R.id.forum:
							mWebView.loadUrl("http://mpets.mobi/forum");
							//mDrawerLayout.closeDrawers();
							return true;
						case R.id.profile:
							mWebView.loadUrl("http://mpets.mobi/profile");
							//mDrawerLayout.closeDrawers();
							return true;
						case R.id.settings:
							Intent settings = new Intent(getApplicationContext(), PrefActivity.class);
							startActivity(settings);
							return true;
						case R.id.edit:
							final Dialog dialog = new Dialog(AuthActivity.this);
							dialog.setContentView(R.layout.edit);
							dialog.show();
							Button b = (Button)dialog.findViewById(R.id.go);
							EditText et = (EditText)dialog.findViewById(R.id.ET);
							et.setText(mWebView.getUrl());
							b.setOnClickListener(new OnClickListener() {
									@Override
									public void onClick(View arg0) {
										EditText et = (EditText)dialog.findViewById(R.id.ET);
										String urli = et.getText().toString();
										if(!urli.contains("mpets.mobi/")) {
											Toast toast = Toast.makeText(getApplicationContext(), "Так нельзя", Toast.LENGTH_SHORT);
											toast.show();
											} else {
											mWebView.loadUrl(urli);
											dialog.cancel();
											}
									}});
							return true;
							case R.id.fav:
								Toast toast = Toast.makeText(getApplicationContext(), "В разработке", Toast.LENGTH_LONG);
								toast.show();
								return true;
							case R.id.notes:
								Intent notes = new Intent(getApplicationContext(), NotesActivity.class);
								startActivity(notes);
								return true;
							case R.id.update:
							new CheckUpdate().execute();
							}
					menuItem.setChecked(true);
					mDrawerLayout.closeDrawers();

					// Add code here to update the UI based on the item selected
					// For example, swap UI fragments here

					return true;
				}
			});
		sp = PreferenceManager.getDefaultSharedPreferences(this);
		mWebView = (WebView) findViewById(R.id.mainWeb);
		// включаем поддержку JavaScript
		mWebView.getSettings().setJavaScriptEnabled(true);
		mWebView.getSettings().setSaveFormData(true);
		mWebView.getSettings().setSavePassword(true);
		mWebView.getSettings().setDefaultTextEncodingName("utf-8");
// указываем страницу загрузки
		mWebView.setWebViewClient(new MyWebViewClient());
		mWebView.loadUrl("http://mpets.mobi/");
	}
	private class MyWebViewClient extends WebViewClient 
	{

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon)
		{
			if(url.contains("wakeup_sleep")) {
				if(i==0) {
				mWebView.stopLoading();
				showAlert();
				}
				else {
					i-=1;
				}}
				else {
			super.onPageStarted(view, url, favicon);
			}
		}
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) 
		{
			view.loadUrl(url);
			return true;
		}
		private void emulateShiftHeld(WebView view)
		{
			try
			{
				KeyEvent shiftPressEvent = new KeyEvent(0, 0, KeyEvent.ACTION_DOWN,
														KeyEvent.KEYCODE_SHIFT_LEFT, 0, 0);
				shiftPressEvent.dispatch(view);
			}
			catch (Exception e)
			{
				Log.e("dd", "Exception in emulateShiftHeld()", e);
			}
		}
		@Override
		public void onPageFinished(WebView view, String url)
		{   
		iNCSG();
			Boolean economy = sp.getBoolean("economy", false);
			Boolean fast = sp.getBoolean("fast", false);
			if(economy == true) {
				mWebView.loadUrl(second_inject);
			} else {
				if(fast==true) {
					
				} else {
				mWebView.loadUrl(first_inject);
			}}
			if(url.equals("http://mpets.mobi/welcome")) {
				Intent i = new Intent(getApplicationContext(), MainActivity.class);
				finish();
				startActivity(i);
			}
			super.onPageFinished(view, url);
		}
	}
	@Override
	public void onBackPressed() {/*при нажатии на кнопку назад открываем предыдущее окно*/
		if(mWebView.canGoBack()) {
			mWebView.goBack();
		} else {
			super.onBackPressed();
		}
	}
	@Override
	protected void onResume()
	{
		iNCSG();
		Boolean economy = sp.getBoolean("economy", false);
		Boolean fast = sp.getBoolean("fast", false);
		if(economy==true){
			mWebView.getSettings().setLoadsImagesAutomatically(false);
		} else {
			mWebView.getSettings().setLoadsImagesAutomatically(true);
		}
		super.onResume();
	}
	class CheckUpdate extends AsyncTask<Void, Void, Void> {
		Elements version;
		private Elements href;
		Document doc;
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params) {
			try {
				PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
				String versionName = packageInfo.versionName;
				doc = Jsoup.connect("http://mpetsx.lark.ru/update.html").get();
				version = doc.select(".version");
				String version_text = version.text();
				href = doc.select(".href");
				String href_text = href.text();
				if(!version_text.equals(versionName)) {
					Log.d("Tag", "" + href_text);
					Log.d("Tag", "" + version_text);
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(href_text));
					startActivity(browserIntent);
					}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
		}
	}
	public boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		// test for connection
		if (cm.getActiveNetworkInfo() != null
			&& cm.getActiveNetworkInfo().isAvailable()
			&& cm.getActiveNetworkInfo().isConnected()) {
			return true;
		} else {
			Log.v("Tag", "Internet Connection Not Present");
			return false;
		}}
	public void iNCSG() {
		try {
			if(isOnline()) {
				// do logic
			} else {
				// show message network is not available.
				Intent i = new Intent(getApplicationContext(), GameActivity.class);
				startActivity(i);
			}} catch(Exception e) {
			Log.d("Tag", "" + e);
		}
	}
	public void showAlert() {
		AlertDialog.Builder ad = new AlertDialog.Builder(AuthActivity.this);
		ad.setTitle("Перед вами важный выбор");  // заголовок
		ad.setMessage("Вы точно хотите разбудить питомца за монеты?"); 
		ad.setNegativeButton("Вовсе не хочу",
			new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int id) {
					dialog.cancel();
				}
			});
		ad.setPositiveButton("Могу себе позволить",
			new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int id) {
					i += 1;
					dialog.cancel();
					mWebView.loadUrl("http://mpets.mobi/wakeup_sleep");
				}
			});
		ad.setCancelable(false);// сообщение
		ad.create();
		ad.show();
	}
	}
