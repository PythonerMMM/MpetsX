package mpets.mobi.x;

import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.widget.*;
import android.preference.*;

public class PrefActivity extends PreferenceActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.prefs);
	}
}
