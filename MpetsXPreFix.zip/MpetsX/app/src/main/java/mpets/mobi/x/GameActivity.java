package mpets.mobi.x;
import android.app.*;
import android.os.*;
import android.view.*;
import java.util.*;
import android.widget.*;

public class GameActivity extends Activity
{
   public int i = 0;
	private Timer myTimer;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.game_main);
		}
		public void no(View v) {
			finish();
		}
		public void yes(View v) {
			setContentView(R.layout.game_screen);
			myTimer = new Timer();
			myTimer.schedule(new TimerTask() {     
					@Override
					public void run() {
						runOnUiThread(new Runnable() {

								@Override
								public void run()
								{
									TextView sec = (TextView)findViewById(R.id.sec);
									i += 1;
									sec.setText(i + " секунд(ы)");
								}
						});
					}

				}, 0, 1000);
				}
		}
