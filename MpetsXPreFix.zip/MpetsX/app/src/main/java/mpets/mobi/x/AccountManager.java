package mpets.mobi.x;

import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.widget.*;
import android.preference.*;
import android.app.*;
import android.view.*;
import android.widget.AdapterView.*;
import java.util.*;
import android.view.ContextMenu.*;
import android.content.*;
import android.util.*;
import java.io.*;

public class AccountManager extends Activity{
private ListView lv;
	private ArrayAdapter<String> adapter;
	public ArrayList<String> accList = new ArrayList<String>();
	public ArrayList<String> nickList = new ArrayList<String>();
	public ArrayList<String> passList = new ArrayList<String>();
	final Context context = this;

	private String SHARED_PREFS_FILE;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.manager);
		lv = (ListView) findViewById(R.id.accountList);
		registerForContextMenu(lv);
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, accList);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view,
										final int position, long id) {
					String oldNick = nickList.get(position);
					String oldPass = passList.get(position);
					final Dialog dialog = new Dialog(context);
					dialog.setContentView(R.layout.edit_account);
					EditText nick = (EditText)dialog.findViewById(R.id.niclET);
					EditText pass = (EditText)dialog.findViewById(R.id.passET);
					nick.setText(oldNick);
					pass.setText(oldPass);
					dialog.show();
					Button b = (Button)dialog.findViewById(R.id.edit);
					b.setOnClickListener(new OnClickListener() {
							@Override
							public void onClick(View arg0) {
								EditText nick = (EditText)dialog.findViewById(R.id.niclET);
								String nickname = nick.getText().toString();
								EditText pass = (EditText)dialog.findViewById(R.id.passET);
								String password = pass.getText().toString();
								nickList.set(position, nickname);
								passList.set(position,password);
								accList.set(position, nickname + ":" + password);								adapter.notifyDataSetChanged();
								dialog.cancel();
							}
						});
	}
	});
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.acc_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// получим идентификатор выбранного пункта меню
		int id = item.getItemId();
		switch(id) {
			case R.id.create_acc:
				final Dialog dialog = new Dialog(this);
				dialog.setContentView(R.layout.add_account);
				dialog.show();
				Button b = (Button)dialog.findViewById(R.id.addAccount);
				b.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View arg0) {
							EditText nick = (EditText)dialog.findViewById(R.id.loginET);
							String nickname = nick.getText().toString();
							EditText pass = (EditText)dialog.findViewById(R.id.passwordET);
							String password = pass.getText().toString();
							nickList.add(nickname);
							passList.add(password);
							accList.add(nickname + ":" + password);
							adapter.notifyDataSetChanged();
							dialog.cancel();
						}});
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.context_menu, menu);
	}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
		switch (item.getItemId()) {
			case R.id.delete:
			    accList.remove(info.position);
				nickList.remove(info.position);
				passList.remove(info.position);
				adapter.notifyDataSetChanged();
				return true;
			default:
				return super.onContextItemSelected(item);
		}
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
	}
}
