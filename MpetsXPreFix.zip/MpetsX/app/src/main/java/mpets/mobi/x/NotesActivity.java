package mpets.mobi.x;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.*;
import android.content.*;
import android.net.*;
import android.view.*;
import android.util.*;
import android.preference.*;
import java.io.*;
import android.content.res.*;
import android.view.View.*;
import java.util.*;
import android.view.ContextMenu.*;
import android.widget.AdapterView.*;
import java.lang.reflect.*;

public class NotesActivity extends Activity
{
	final Context context = this;
	private ListView lv;
	public ArrayList<String> text = new ArrayList<String>();
	public ArrayList<String> zag = new ArrayList<String>();
	private ArrayAdapter<String> adapter;
	private String SHARED_PREFS_FILE;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notes);
		//
		lv = (ListView) findViewById(R.id.lv);
		registerForContextMenu(lv);
		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, zag);
		lv.setAdapter(adapter);
		lv.setOnItemClickListener(new OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view,
										final int position, long id) {
					final Dialog dialog = new Dialog(context);
					dialog.setContentView(R.layout.note);
					dialog.show();
					TextView note_text = (TextView)dialog.findViewById(R.id.note_text);
					String texttt = text.get(position);
					note_text.setText(texttt);
											}});
		}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.notes_menu, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// получим идентификатор выбранного пункта меню
		int id = item.getItemId();
		switch(id) {
			case R.id.note_add:
				final Dialog dialog = new Dialog(this);
				dialog.setContentView(R.layout.add_note);
				dialog.show();
				Button b = (Button)dialog.findViewById(R.id.notes_save);
				b.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View arg0) {
							EditText zage = (EditText)dialog.findViewById(R.id.notes_zag);
							EditText texte = (EditText)dialog.findViewById(R.id.notes_text);
							String zagg = zage.getText().toString();

							String textt = texte.getText().toString();
							text.add(textt);
							zag.add(zagg);
							SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
							SharedPreferences.Editor mEdit1 = sp.edit();
							/* sKey is an array */
							mEdit1.putInt("zag", zag.size());  

							for(int i=0;i<zag.size();i++)  
							{
								mEdit1.remove("zag_" + i);
								mEdit1.putString("zag_" + i, zag.get(i));  
							}
							mEdit1.putInt("text", text.size());  

							for(int i=0;i<text.size();i++)  
							{
								mEdit1.remove("text_" + i);
								mEdit1.putString("text_" + i, text.get(i));  
							}
							mEdit1.commit();
							adapter.notifyDataSetChanged();
							dialog.cancel();
						}});
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
	super.onCreateContextMenu(menu, v, menuInfo);

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.notes_context_menu, menu);
		}
	@Override
	public boolean onContextItemSelected(MenuItem item) {
	AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
		switch (item.getItemId()) {
		case R.id.note_delete:
				zag.remove(info.position);
				text.remove(info.position);
				adapter.notifyDataSetChanged();
				return true;
				default:
			return super.onContextItemSelected(item);
				}
	}

	@Override
	protected void onResume()
	{
		try {
			
	SharedPreferences mSharedPreference1 =   PreferenceManager.getDefaultSharedPreferences(context);
	zag.clear();
	text.clear();
		int zage = mSharedPreference1.getInt("zag", 0);  
        int texte = mSharedPreference1.getInt("text", 0);
		for(int i=0;i<zage;i++) 
		{
			zag.add(mSharedPreference1.getString("zag_" + i, null));
	}
		for(int i=0;i<texte;i++) 
	{
			text.add(mSharedPreference1.getString("text_" + i, null));
		}
		adapter.notifyDataSetChanged();
		} catch(Exception e) {
			Log.d("Tag", "" + e);
		}
		super.onResume();
	}
		}
